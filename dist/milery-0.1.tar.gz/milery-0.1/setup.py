from setuptools import setup

setup(name='milery',
      version='0.1',
      description='Tasks network demonstration',
      author='Vadim Gusev',
      author_email='vadimii@me.com',
      url='https://github.com/vadimii/tasknet',
      packages=['milery'],
      install_requires=['celery'])
